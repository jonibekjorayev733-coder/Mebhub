import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

interface Question {
  id: number;
  q: string;
  opts: string[];
  correct: number;
  difficulty: string;
  explanation: string;
  points: number;
}

export default function KrosswordGame() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<(number | null)[]>([]);
  const [answered, setAnswered] = useState(false);
  const [loading, setLoading] = useState(true);

  const MOCK_QUESTIONS: Question[] = [
    {
      id: 1,
      q: "O'zbekistonning poytaxti (8 harf)",
      opts: ["Toshkent", "Samarqand", "Buxoro", "Farg'ona"],
      correct: 0,
      difficulty: "Oson",
      explanation: "Toshkent - O'zbekistonning poytaxti",
      points: 10,
    },
    {
      id: 2,
      q: "Eng katta sayyora (8 harf)",
      opts: ["Saturn", "Mars", "Yupiter", "Neptun"],
      correct: 2,
      difficulty: "O'rta",
      explanation: "Yupiter - quyosh sistemasining eng katta sayyorasi",
      points: 10,
    },
    {
      id: 3,
      q: "Sinf nutnasi so'zi (8 harf)",
      opts: ["Direkto", "Nazorat", "Ekzamen", "Dars"],
      correct: 2,
      difficulty: "O'rta",
      explanation: "Ekzamen - bilimni tekshirish jarayoni",
      points: 10,
    },
    {
      id: 4,
      q: "Eng katta okean (5 harf)",
      opts: ["Tinch", "Atlantik", "Hind", "Arktik"],
      correct: 0,
      difficulty: "Oson",
      explanation: "Tinch okeyan eng katta va chuqurligi bilan birinchi",
      points: 10,
    },
    {
      id: 5,
      q: "Quyosh turli taraflardan o'pka _____ deyiladi",
      opts: ["Atmosfera", "Oksigen", "Gaz", "Aeroplan"],
      correct: 0,
      difficulty: "O'rta",
      explanation: "Atmosfera - Yer atmosferasi",
      points: 10,
    },
    {
      id: 6,
      q: "Tibbiy mutaxassisning nomi (6 harf)",
      opts: ["Doktor", "Shifa", "Kasallik", "Vosita"],
      correct: 0,
      difficulty: "Oson",
      explanation: "Doktor - tibbiy mutaxassisning nomi",
      points: 10,
    },
    {
      id: 7,
      q: "Shuʼlasi bo'lgan yog'in ____",
      opts: ["Yulduz", "Mash'ala", "Olov", "Chiroq"],
      correct: 1,
      difficulty: "O'rta",
      explanation: "Mash'ala - shuʼlasi bo'lgan yog'in yoqilg'i",
      points: 10,
    },
    {
      id: 8,
      q: "Kitoblarning to'plami (8 harf)",
      opts: ["Kutubxona", "Qutisi", "Polka", "Javon"],
      correct: 0,
      difficulty: "O'rta",
      explanation: "Kutubxona - kitoblarning to'plamining joylashgan joy",
      points: 10,
    },
    {
      id: 9,
      q: "Bahor faslining oxiri (4 harf)",
      opts: ["Iyun", "May", "Aprel", "Mart"],
      correct: 1,
      difficulty: "Oson",
      explanation: "May - bahor faslining oxiri",
      points: 10,
    },
    {
      id: 10,
      q: "Olim kim ko'plab asboblar ixtiro qilgan (6 harf)",
      opts: ["Edisson", "Nyuton", "Gallilei", "Boyl"],
      correct: 0,
      difficulty: "Qiyin",
      explanation: "Edisson - ko'plab elektr asboblarini ixtiro qilgan",
      points: 10,
    },
  ];

  useEffect(() => {
    loadQuestions();
  }, []);

  const loadQuestions = async () => {
    try {
      const response = await fetch("http://localhost:8000/games/questions/krossword");
      const data = await response.json();
      if (data && data.length > 0) {
        setQuestions(data.slice(0, 10));
      } else {
        setQuestions(MOCK_QUESTIONS);
      }
    } catch (error) {
      console.error("Error loading questions:", error);
      setQuestions(MOCK_QUESTIONS);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setSelectedAnswers(new Array(questions.length).fill(null));
  }, [questions]);

  const handleAnswer = (index: number) => {
    setSelectedAnswers(prev => {
      const updated = [...prev];
      updated[currentQuestion] = index;
      return updated;
    });
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setAnswered(false);
    } else {
      calculateScore();
      setAnswered(true);
    }
  };

  const calculateScore = () => {
    let total = 0;
    selectedAnswers.forEach((answer, idx) => {
      if (answer === questions[idx]?.correct) {
        total += questions[idx]?.points || 0;
      }
    });
    setScore(total);
  };

  const handleSubmit = () => {
    calculateScore();
    setAnswered(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-lg font-semibold">Savollar yuklanmadi</p>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];
  const currentAnswer = selectedAnswers[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto pt-8">
        {/* Header */}
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Krossword O'yini</h1>
          <p className="text-gray-600">So'rov {currentQuestion + 1} / {questions.length}</p>
        </div>

        {/* Progress */}
        <div className="mb-6">
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
            <div
              className="bg-indigo-600 h-3 rounded-full transition-all duration-300"
              style={{
                width: `${((currentQuestion + 1) / questions.length) * 100}%`,
              }}
            />
          </div>
          <p className="text-sm text-gray-600 text-center">
            {Math.round(((currentQuestion + 1) / questions.length) * 100)}% % davomiylik
          </p>
        </div>

        {/* Question */}
        <Card className="mb-6 border-2 border-indigo-300">
          <CardHeader className="bg-indigo-100">
            <CardTitle className="text-2xl text-gray-800">{currentQ.q}</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-3">
              {currentQ.opts.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(idx)}
                  className={`w-full p-4 rounded-lg text-left font-semibold transition-all border-2 ${
                    currentAnswer === idx
                      ? "bg-indigo-500 text-white border-indigo-600"
                      : "bg-white border-gray-300 hover:border-indigo-500 text-gray-700"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex gap-3 justify-center mb-6">
          {!answered ? (
            <Button
              onClick={handleNext}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg"
            >
              {currentQuestion === questions.length - 1 ? "Natijani Ko'rish" : "Keyingi"}
            </Button>
          ) : (
            <Button
              onClick={() => {
                setCurrentQuestion(0);
                setSelectedAnswers(new Array(questions.length).fill(null));
                setAnswered(false);
                setScore(0);
              }}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg"
            >
              Qayta Boshlash
            </Button>
          )}
        </div>

        {/* Results */}
        {answered && (
          <Card className="bg-indigo-50 border-indigo-300">
            <CardHeader>
              <CardTitle className="text-center text-2xl">✅ Natija</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <div className="text-6xl font-bold text-indigo-600 mb-2">{score}</div>
                <p className="text-gray-600">Jami balldan {score} ball to'plandiz</p>
              </div>

              {/* Detailed Results */}
              <div className="space-y-3">
                {questions.map((q, idx) => {
                  const answer = selectedAnswers[idx];
                  const isCorrect = answer === q.correct;
                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-lg border-2 ${
                        isCorrect
                          ? "bg-green-50 border-green-300"
                          : "bg-red-50 border-red-300"
                      }`}
                    >
                      <p className="font-semibold text-gray-800">{q.q}</p>
                      <p className="text-sm text-gray-600 mt-1">
                        To'g'ri javob: {q.opts[q.correct]}
                      </p>
                      {!isCorrect && (
                        <p className="text-sm text-gray-600">
                          Sizning javobingiz: {answer !== null ? q.opts[answer] : "Javob berilmadi"}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
