import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Volume2, RotateCcw, Home } from 'lucide-react';

interface Question {
  id: string;
  country: string;
  capital: string;
  question: string;
  options: string[];
  correct: number;
}

const QUESTIONS: Question[] = [
  {
    id: 'delhi',
    country: 'Delhi',
    capital: 'Delhi',
    question: 'Temur 1398-yilda qaysi shaharni bosib oldi?',
    options: ['Delhi', 'Baghdad', 'Istanbul', 'Cairo'],
    correct: 0
  },
  {
    id: 'baghdad',
    country: 'Baghdad',
    capital: 'Baghdad',
    question: 'Temur 1401-yilda qaysi shaharni bosib oldi?',
    options: ['Delhi', 'Baghdad', 'Damascus', 'Istanbul'],
    correct: 1
  },
  {
    id: 'damascus',
    country: 'Damascus',
    capital: 'Damascus',
    question: 'Temur 1400-yilda qaysi shaharni bosib oldi?',
    options: ['Baghdad', 'Damascus', 'Cairo', 'Istanbul'],
    correct: 1
  },
  {
    id: 'ankara',
    country: 'Ankara',
    capital: 'Ankara',
    question: 'Temur 1402-yilda qaysi xonligning poytaxti Ankаrani bosib oldi?',
    options: ['Osman', 'Safaviy', 'Mog\'ullar', 'Sharq'],
    correct: 0
  },
  {
    id: 'samarkand',
    country: 'Samarkand',
    capital: 'Samarkand',
    question: 'Temurning paytaxti qaysi shahar edi?',
    options: ['Buxoro', 'Samarkand', 'Xiva', 'Tashkent'],
    correct: 1
  }
];

// Xarita koordinatalari - har bir davlat
const COUNTRY_POSITIONS = {
  delhi: { x: 75, y: 55, flag: '🇮🇳' },
  baghdad: { x: 45, y: 40, flag: '🇮🇶' },
  damascus: { x: 40, y: 35, flag: '🇸🇾' },
  ankara: { x: 35, y: 30, flag: '🇹🇷' },
  samarkand: { x: 50, y: 20, flag: '🇺🇿' }
};

interface GameState {
  phase: 'map' | 'question' | 'answer' | 'gameover' | 'victory';
  currentQuestion: number;
  score: number;
  conquered: string[];
  selectedAnswer: number | null;
  isAnswered: boolean;
}

export default function TemurConquestGameV2() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const [gameState, setGameState] = useState<GameState>({
    phase: 'map',
    currentQuestion: 0,
    score: 0,
    conquered: [],
    selectedAnswer: null,
    isAnswered: false
  });

  const [allQuestions, setAllQuestions] = useState<Question[]>(QUESTIONS);

  // Fetch custom tests
  useEffect(() => {
    const fetchCustomTests = async () => {
      try {
        const response = await fetch('http://localhost:8000/custom-tests/game/temur-conquest');
        if (!response.ok) {
          throw new Error("Server ishlamayapti");
        }
        const customTests = await response.json();
        const transformedTests: Question[] = customTests.map((test: any, idx: number) => ({
          id: `custom_${idx}`,
          country: test.question.split(' ')[0] || 'Custom',
          capital: test.question.split(' ')[0] || 'Custom',
          question: test.question,
          options: test.options,
          correct: test.correct_index
        }));
        setAllQuestions([...QUESTIONS, ...transformedTests]);
        console.log("Custom tests loaded:", transformedTests.length);
      } catch (error) {
        console.error("Custom tests fetch error:", error);
        setAllQuestions(QUESTIONS);
      }
    };
    fetchCustomTests();
  }, []);

  const currentQuestion = allQuestions[gameState.currentQuestion];

  const handleCountryClick = (countryId: string) => {
    if (gameState.conquered.includes(countryId)) {
      toast({
        title: "ℹ️ Allaqachon bosib olingan",
        description: "Bu davlat allaqachon bosib olingan!",
      });
      return;
    }

    // To'g'ri savol topshirish uchun davlatni bosib olish
    const matchingQuestion = allQuestions.find(
      q => q.id.toLowerCase() === countryId.toLowerCase()
    );

    if (matchingQuestion) {
      setGameState(prev => ({
        ...prev,
        phase: 'question',
        currentQuestion: allQuestions.indexOf(matchingQuestion),
        selectedAnswer: null,
        isAnswered: false
      }));
    } else {
      // Agar savol bo'lmasa, shunchaki bosib olingan deb belgilash
      setGameState(prev => ({
        ...prev,
        conquered: [...prev.conquered, countryId],
        score: prev.score + 100
      }));
      toast({
        title: "✅ Bosib olingan",
        description: "Davlat muvaffaqiyatli bosib olingan!",
      });
    }
  };

  const handleAnswer = (index: number) => {
    if (gameState.isAnswered) return;

    setGameState(prev => ({
      ...prev,
      selectedAnswer: index,
      isAnswered: true
    }));

    if (index === currentQuestion.correct) {
      toast({
        title: "✅ To'g'ri!",
        description: "Javob to'g'ri! Davlatni bosib oldingiz!",
      });

      setTimeout(() => {
        const newConquered = [...gameState.conquered, currentQuestion.id];
        const newScore = gameState.score + 100;
        const isVictory = newConquered.length === allQuestions.length;

        setGameState(prev => ({
          ...prev,
          phase: isVictory ? 'victory' : 'map',
          conquered: newConquered,
          score: newScore,
          selectedAnswer: null,
          isAnswered: false
        }));
      }, 1500);
    } else {
      toast({
        title: "❌ Noto'g'ri",
        description: `To'g'ri javob: ${currentQuestion.options[currentQuestion.correct]}`,
        variant: "destructive",
      });

      setTimeout(() => {
        setGameState(prev => ({
          ...prev,
          phase: 'gameover'
        }));
      }, 2000);
    }
  };

  const handlePlayAgain = () => {
    setGameState({
      phase: 'map',
      currentQuestion: 0,
      score: 0,
      conquered: [],
      selectedAnswer: null,
      isAnswered: false
    });
  };

  const handleHome = () => {
    navigate('/');
  };

  const playSound = (type: 'correct' | 'wrong' | 'click') => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    if (type === 'correct') {
      oscillator.frequency.value = 800;
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } else if (type === 'wrong') {
      oscillator.frequency.value = 200;
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-amber-900 to-slate-900 flex flex-col">
      {/* Top Bar */}
      <div className="sticky top-0 z-20 bg-gradient-to-r from-amber-900 to-yellow-900 border-b-4 border-yellow-600 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-4xl font-black text-yellow-300 drop-shadow-lg">
              ⚔️ TEMUR'S CONQUEST - XARITA
            </h1>
            <p className="text-yellow-100 font-bold mt-1">
              Davlatlar soni: {gameState.conquered.length}/{allQuestions.length} | Ball: {gameState.score}
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={handlePlayAgain}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-2 rounded-lg"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Qayta
            </Button>
            <Button
              onClick={handleHome}
              className="bg-gray-600 hover:bg-gray-700 text-white font-bold px-6 py-2 rounded-lg"
            >
              <Home className="w-5 h-5 mr-2" />
              Bosh
            </Button>
          </div>
        </div>
      </div>

      {gameState.phase === 'map' && (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          {/* Xarita */}
          <Card className="w-full max-w-4xl bg-gradient-to-br from-amber-100 to-yellow-100 border-4 border-yellow-600 rounded-2xl overflow-hidden shadow-2xl">
            <div className="relative w-full aspect-video">
              {/* Xarita foni */}
              <div className="absolute inset-0 bg-gradient-to-br from-blue-300 via-green-200 to-yellow-100 opacity-50"></div>

              {/* Davlatlar va bayroqlar */}
              {QUESTIONS.map((question) => {
                const isConquered = gameState.conquered.includes(question.id);
                const pos = COUNTRY_POSITIONS[question.id as keyof typeof COUNTRY_POSITIONS];

                return (
                  <div
                    key={question.id}
                    className="absolute group cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-300 hover:scale-125"
                    style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                    onClick={() => handleCountryClick(question.id)}
                  >
                    {/* Davlat markeri */}
                    <div
                      className={`w-16 h-16 rounded-full flex items-center justify-center text-4xl font-bold border-4 transition-all duration-300 shadow-lg ${
                        isConquered
                          ? 'bg-gradient-to-br from-red-500 to-red-700 border-red-900 scale-110'
                          : 'bg-gradient-to-br from-blue-400 to-blue-600 border-blue-800 hover:scale-125'
                      }`}
                    >
                      {pos.flag}
                    </div>

                    {/* Bayroq animasiyasi - bosib olinganlar uchun */}
                    {isConquered && (
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 animate-bounce">
                        <span className="text-3xl">🚩</span>
                      </div>
                    )}

                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 whitespace-nowrap transition-opacity pointer-events-none">
                      {question.country}
                      {isConquered && ' ✅ Bosib olingan'}
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Qo'shimcha ma'lumot */}
          <div className="mt-8 text-center text-yellow-100 font-bold text-lg">
            <p>⬆️ Davlat ustiga bosing va savolga javob bering!</p>
            <p className="mt-2">✅ To'g'ri javob bersan, davlat Temur imperiyasiga kiradi</p>
          </div>
        </div>
      )}

      {gameState.phase === 'question' && currentQuestion && (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <Card className="w-full max-w-2xl bg-gradient-to-br from-slate-800 to-slate-900 border-4 border-yellow-500 rounded-2xl p-8 shadow-2xl">
            {/* Davlat sarlavhasi */}
            <div className="text-center mb-8">
              <div className="text-6xl mb-4">{COUNTRY_POSITIONS[currentQuestion.id as keyof typeof COUNTRY_POSITIONS]?.flag}</div>
              <h2 className="text-3xl font-black text-yellow-300 mb-2">{currentQuestion.country}</h2>
              <p className="text-slate-300 font-semibold">{currentQuestion.question}</p>
            </div>

            {/* Javob variantlari */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {currentQuestion.options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(idx)}
                  disabled={gameState.isAnswered}
                  className={`p-4 rounded-xl font-bold text-lg transition-all duration-300 border-2 ${
                    gameState.selectedAnswer === idx
                      ? idx === currentQuestion.correct
                        ? 'bg-green-600 border-green-400 text-white scale-105'
                        : 'bg-red-600 border-red-400 text-white scale-105'
                      : gameState.isAnswered && idx === currentQuestion.correct
                      ? 'bg-green-600 border-green-400 text-white'
                      : 'bg-slate-700 border-slate-500 text-slate-100 hover:bg-slate-600'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>

            {gameState.isAnswered && (
              <div className="text-center">
                {gameState.selectedAnswer === currentQuestion.correct ? (
                  <p className="text-green-400 font-bold text-xl">✅ To'g'ri! Davlat bosib olinmoqda...</p>
                ) : (
                  <p className="text-red-400 font-bold text-xl">❌ Noto'g'ri! Game Over</p>
                )}
              </div>
            )}
          </Card>
        </div>
      )}

      {gameState.phase === 'gameover' && (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <Card className="w-full max-w-2xl bg-gradient-to-br from-red-900 to-red-950 border-4 border-red-500 rounded-2xl p-12 shadow-2xl text-center">
            <h2 className="text-5xl font-black text-red-300 mb-4">💀 GAME OVER</h2>
            <p className="text-2xl font-bold text-red-100 mb-6">
              Siz {gameState.conquered.length} davlatni bosib oldingiz
            </p>
            <p className="text-3xl font-black text-yellow-300 mb-8">
              Jami Ball: {gameState.score}
            </p>
            <Button
              onClick={handlePlayAgain}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-4 text-xl rounded-lg"
            >
              <RotateCcw className="w-6 h-6 mr-2" />
              Qayta O'ynash
            </Button>
          </Card>
        </div>
      )}

      {gameState.phase === 'victory' && (
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <Card className="w-full max-w-2xl bg-gradient-to-br from-green-900 to-emerald-950 border-4 border-green-400 rounded-2xl p-12 shadow-2xl text-center">
            <h2 className="text-5xl font-black text-green-300 mb-4">🏆 VICTORY!</h2>
            <p className="text-2xl font-bold text-green-100 mb-2">
              Temur imperiyasi to'liq qurildi!
            </p>
            <p className="text-xl text-green-100 mb-6">
              Siz barcha {allQuestions.length} davlatni bosib oldingiz
            </p>
            <p className="text-3xl font-black text-yellow-300 mb-8">
              Jami Ball: {gameState.score}
            </p>
            <Button
              onClick={handlePlayAgain}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-8 py-4 text-xl rounded-lg"
            >
              <RotateCcw className="w-6 h-6 mr-2" />
              Qayta O'ynash
            </Button>
          </Card>
        </div>
      )}
    </div>
  );
}
